#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <string.h>

#define SIZE 1000000000

void parallelMerge(long *vector, int size, int myHeight);
void merge(long *vector, long l, long mid, long r);
int compare(const void *left, const void *right);
int validate(long *vector, int size);
void mergesort(long *vector, long l, long r);

int main(int argc, char *argv[])
{
    double starting = MPI_Wtime();
    int myRank, nProc;
    int rc;
    int size = SIZE;
    int size2 = SIZE / 8;
    long *vector, *vector2;
    double start, middle, finish;
    int i;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
    MPI_Comm_size(MPI_COMM_WORLD, &nProc);

    if (myRank == 0)
    {
        if (nProc != 8)
        {
            printf("%d Nodes detected.\n", nProc);
            printf("Number of nodes required: 8\nProgram is hence being aborted.\n");
            printf("Please re-run the program with 8 nodes.\n");
            MPI_Abort(MPI_COMM_WORLD, 0);
        }
        else
        {
            printf("8 Nodes detected. Program proceeding ahead.\n");
        }
    }
    MPI_Barrier(MPI_COMM_WORLD);
    srand(time(0));
    vector2 = (long *) malloc(size2 * sizeof(long));
    for (i = 0; i < size2; i++)
    {
        vector2[i] = rand();
    }
    if (myRank == 0)
    {
        vector = (long *) malloc(size * sizeof(long));
    }

    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Gather(vector2, size2, MPI_LONG, vector, size2, MPI_LONG, 0, MPI_COMM_WORLD);

    if (myRank == 0)
    {
        int rootHt = 0, nodeCount = 1;
        while (nodeCount < nProc)
        {
            nodeCount += nodeCount;
            rootHt++;
        }
        printf ("%d processes mandates root height of %d\n", nProc, rootHt);

        start = MPI_Wtime();
        parallelMerge (vector, size, rootHt);
        middle = MPI_Wtime();
    }
    else
    {
        int iVect[2], height, parent;
        MPI_Status status;

        MPI_Recv(iVect, 2, MPI_INT, MPI_ANY_SOURCE, 1, MPI_COMM_WORLD, &status);
        size   = iVect[0];
        height = iVect[1];
        vector = (long *) calloc(size, sizeof(*vector));

        MPI_Recv(vector, size, MPI_LONG, MPI_ANY_SOURCE, 2, MPI_COMM_WORLD, &status);
        parallelMerge (vector, size, height);

        MPI_Finalize();
        return 0;
    }

    rc = validate(vector, size);
    if (rc == 1)
    {
        printf("Sorting successful.\n");
    }
    else
    {
        printf("Error.\n");
    }

    finish = MPI_Wtime();
    printf("Parallel sorting time: %3.3f\n", (middle-start));
    MPI_Finalize();
}

int validate(long *vector, int size)
{
    int k;
    // FILE *abc;
    // abc = fopen("output.txt", "w");
    // fprintf(abc, "%ld\n", vector[0]);
    for (k = 0; k < size - 1; ++k)
    {
        // fprintf(abc, "%ld\n", vector[k + 1]);
        if (vector[k] > vector[k + 1])
        {
            return 0;
        }
    }
    // fclose(abc);
    return 1;
}

void merge(long *vector, long l, long mid, long r)
{
    long n1 = mid - l + 1;
    long n2 = r - mid;
    long *L = (long *) malloc(n1 * sizeof(long));
    long *R = (long *) malloc(n2 * sizeof(long));
    long i, j, k;

    for (i = 0; i < n1; i++)
    {
        L[i] = vector[i + l];
    }
    for (i = 0; i < n2; i++)
    {
        R[i] = vector[mid + 1 + i];
    }
    i = j = 0;
    k = l;
    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            vector[k++] = L[i++];
        }
        else
        {
            vector[k++] = R[j++];
        }
    }
    while (i < n1)
    {
        vector[k++] = L[i++];
    }
    while (j < n2)
    {
        vector[k++] = R[j++];
    }
}

void mergesort(long *vector, long l, long r)
{
    if (l < r)
    {
        long mid = l + (r - l) / 2;
        mergesort(vector, l, mid);
        mergesort(vector, mid + 1, r);
        merge(vector, l, mid, r);
    }
}

void parallelMerge(long *vector, int size, int myHeight)
{  
    int parent;
    int myRank, nProc;
    int nxt, rtChild;

    MPI_Comm_rank (MPI_COMM_WORLD, &myRank);
    MPI_Comm_size (MPI_COMM_WORLD, &nProc);

    parent = myRank & ~(1 << myHeight);
    nxt = myHeight - 1;
    if (nxt >= 0)
    {
        rtChild = myRank | (1 << nxt);
    }
    if (myHeight > 0)
    {
        if (rtChild >= nProc)
        {
            parallelMerge(vector, size, nxt);
        }
        else
        {
            int left_size  = size / 2, right_size = size - left_size;
            long *leftArray = (long *) calloc(left_size, sizeof(*leftArray)),
                 *rightArray = (long *) calloc (right_size, sizeof(*rightArray));
            int iVect[2];
            int i, j, k;
            MPI_Status status;

            memcpy(leftArray, vector, left_size * sizeof(*leftArray));
            memcpy(rightArray, vector+left_size, right_size * sizeof(*rightArray));

            iVect[0] = right_size;
            iVect[1] = nxt;
            MPI_Send(iVect, 2, MPI_INT, rtChild, 1, MPI_COMM_WORLD);
            MPI_Send(rightArray, right_size, MPI_LONG, rtChild, 2, MPI_COMM_WORLD);

            parallelMerge(leftArray, left_size, nxt);
            MPI_Recv(rightArray, right_size, MPI_LONG, rtChild, 3, MPI_COMM_WORLD, &status);

            i = j = k = 0;
            while (i < left_size && j < right_size)
            {
                if (leftArray[i] > rightArray[j])
                {    
                    vector[k++] = rightArray[j++];
                }
                else
                {
                    vector[k++] = leftArray[i++];
                }
            }
            
            while (i < left_size)
            {
                vector[k++] = leftArray[i++];
            }
            while (j < right_size)
            {
                vector[k++] = rightArray[j++];
            }
        }
    }
    else
    {
        qsort(vector, size, sizeof *vector, compare);
        // mergesort(vector, 0, SIZE / 8);
    }

    if ( parent != myRank )
    {
        MPI_Send(vector, size, MPI_LONG, parent, 3, MPI_COMM_WORLD);
    }
}

int compare(const void *left, const void *right)
{
    long *lt = (long *) left,
         *rt = (long *) right,
         diff = *lt - *rt;

    if (diff < 0) return -1;
    if (diff > 0) return +1;
    return 0;
}
